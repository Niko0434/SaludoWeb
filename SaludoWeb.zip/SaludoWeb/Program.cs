// Default.aspx.cs

using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Web.UI;

namespace SaludoWeb
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Mostrar un saludo al cargar la p�gina por primera vez
                string horaSaludo = ObtenerHoraSaludo();
                lblSaludo.Text = $"�Hola! Buenos {horaSaludo}.";
            }
        }

        private string ObtenerHoraSaludo()
        {
            // Obtener la hora actual para determinar el saludo
            DateTime ahora = DateTime.Now;
            if (ahora.Hour >= 5 && ahora.Hour < 12)
            {
                return "d�as";
            }
            else if (ahora.Hour >= 12 && ahora.Hour < 18)
            {
                return "tardes";
            }
            else
            {
                return "noches";
            }
        }
    }
}
